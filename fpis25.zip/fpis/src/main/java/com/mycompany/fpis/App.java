package com.mycompany.fpis;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
    AnnotationConfigApplicationContext context;

    @Override
    public void start(Stage stage) throws IOException {
  
        context = new AnnotationConfigApplicationContext(AppConfig.class);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/primary.fxml"));
        loader.setControllerFactory(context::getBean);
         Parent root = loader.load();
        
        
//        scene = new Scene(loadFXML("primary"), 640, 480);
        
//        primaryStage.setScene(new Scene(loader.load()));
//        primaryStage.setTitle("User Management");
//        primaryStage.show();
         scene = new Scene(root, 640, 480);

        stage.setScene(scene);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        if (scene == null) {
            throw new IllegalStateException("Scene has not been initialized yet!");
        }

        FXMLLoader loader = new FXMLLoader(App.class.getResource("/fxml/" + fxml + ".fxml"));
       // loader.setControllerFactory(context::getBean);
        Parent root = loader.load();
        scene.setRoot(root);
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}
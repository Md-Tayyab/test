/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fpis.model;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;

public class DozerExample {
    public static void main(String[] args) {
        // Create a Dozer mapper instance
        Mapper mapper = DozerBeanMapperBuilder.create()
                .withMappingFiles("dozer.xml") // Load the dozer.xml configuration
                .build();

        // Create a source object
        SourceClass source = new SourceClass();
        source.setName("John Doe");
        source.setAge(30);

        // Map the source object to the destination object
        DestinationClass destination = mapper.map(source, DestinationClass.class);

        // Print the result
        System.out.println("Full Name: " + destination.getFullName());
        System.out.println("Years: " + destination.getYears());
    }
}

package com.mycompany.fpis;

import com.mycompany.fpis.model.User;
import com.mycompany.fpis.service.UserService;
import java.io.IOException;
import java.util.List;
import javafx.fxml.FXML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PrimaryController {
    
    @Autowired
    UserService users;
    
//    @Autowired
//    public PrimaryController(UserService userService) {
//        this.users = userService;
//    }
    
    @FXML
    private void switchToSecondary() throws IOException {
       // this.users = new UserService();
         List<User> allUsers = users.getAllUsers();
        for (User allUser : allUsers) {
            System.err.println("Test : "+allUser.getName());
        }
       // App.setRoot("secondary");
      
        
        
        
    }
}

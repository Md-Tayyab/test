/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fpis.controller;


import com.mycompany.fpis.model.User;
import com.mycompany.fpis.service.UserService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.stereotype.Component;

@Component
public class UserController {
    private final UserService userService;
    private ObservableList<User> users = FXCollections.observableArrayList();

    @FXML private TextField nameField;
    @FXML private TextField emailField;
    @FXML private TableView<User> userTable;
    @FXML private TableColumn<User, String> nameColumn;
    @FXML private TableColumn<User, String> emailColumn;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @FXML
    public void initialize() {
        users.addAll(userService.getAllUsers());
        userTable.setItems(users);
    }

    @FXML
    public void handleSave() {
        User user = new User();
        user.setName(nameField.getText());
        user.setEmail(emailField.getText());

        userService.saveUser(user);
        users.add(user);
        nameField.clear();
        emailField.clear();
    }

    @FXML
    public void handleDelete() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            userService.deleteUser(selectedUser.getId());
            users.remove(selectedUser);
        }
    }
}

